package org.example.bean;

public abstract class GenericData {

}
